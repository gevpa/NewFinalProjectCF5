// import { useEffect, useState } from "react"
// import Post from "../Post"
// // import { response } from "express";

// export default function IndexPage() {
//     const [posts, setPosts] = useState([]);
//     useEffect(() => {
//         fetch('http://localhost:4000/post').then(response => {
//             response.json().then(posts => {
//                 setPosts(posts);
//             });
//         });
//     }, []);
//     return (
//         <>
//            {posts.length > 0 && posts.map(post => (
//             <Post />
//            ))}
//         </>
//     )
// }


// import { useEffect, useState } from "react";
// import Post from "../Post";

// export default function IndexPage() {
//   const [posts, setPosts] = useState([]);

//   useEffect(() => {
//     fetch('http://localhost:4000/post')
//       .then(response => response.json())
//       .then(data => setPosts(data));
//   }, []);

//   return (
//     <>
//       {posts.length > 0 && posts.map(post => (
//         <Post
//           key={post.id} // Assuming each post has a unique 'id'
//           title={post.title}
//           summary={post.summary}
//           cover={post.cover}
//           content={post.content}
//           createdAt={post.createdAt}
//           author={post.author}
//         />
//       ))}
//     </>
//   );
// }

// import { useEffect, useState } from "react";
// import Post from "../Post";

// export default function IndexPage() {
//   const [posts, setPosts] = useState([]);

//   useEffect(() => {
//     fetch('http://localhost:4000/post')
//       .then(response => response.json())
//       .then(posts => {
//         console.log("Fetched posts:", posts); // Log the fetched posts
//         setPosts(posts);
//       });
//   }, []);

//   return (
//     <>
//       {posts.length > 0 && posts.map(post => (
//         <Post
//           key={post.id} // Assuming each post has a unique 'id'
//           title={post.title}
//           summary={post.summary}
//           cover={post.cover}
//           content={post.content}
//           createdAt={post.createdAt}
//           author={post.author}
//         />
//       ))}
//     </>
//   );
// }

import { useEffect, useState } from "react";
import Post from "../Post";

export default function IndexPage() {
    const [posts, setPosts] = useState([]);
    useEffect(() => {
        fetch('http://localhost:4000/post')
            .then(response => response.json())
            .then(posts => setPosts(posts));
    }, []);

    return (
        <>
            {posts.length > 0 && posts.map(post => (
                <Post key={post._id} {...post} />
            ))}
        </>
    );
}

