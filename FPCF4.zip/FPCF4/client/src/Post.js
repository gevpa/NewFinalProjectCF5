import { formatISO9075 } from "date-fns";
import { useEffect } from "react";
import { Link } from "react-router-dom";

export default function Post({_id, title, summary, cover, content, createdAt, author }) {
  // Check if createdAt is a valid date
  const validDate = createdAt ? new Date(createdAt) : new Date();

  // Fallback if the date is invalid
  const formattedDate = isNaN(validDate.getTime()) ? 'Invalid Date' : formatISO9075(validDate);

  // Ensure author is defined and has a username
  const authorName = author && author.username ? author.username : 'Unknown Author';

  // Log the cover image URL to ensure it is correct
  useEffect(() => {
    console.log("Cover Image URL:", cover);
  }, [cover]);

  return (
    <div className="post">
      <div className="image">
        <Link to={`/post/${_id}`}>
        <img src={'http://localhost:4000/'+cover} alt="Post cover" onError={(e) => {e.target.src='https://techcrunch.com/wp-content/uploads/2024/02/GettyImages-1132225622-e1709210197672.jpg?w=850&h=492&crop=1';}}></img>
        </Link>
        
      </div>
      <div className="texts">
      <Link to={`/post/${_id}`}>
        <h2>{title}</h2>
      </Link>  
        <p className="info">
          <a className="author">{authorName}</a>
          <time>{formattedDate}</time>
        </p>
        <p className="summary">{summary}</p>
      </div>
    </div>
  );
}
